/**
 * 
 */
package business;

import business.exception.ServiceLoadingException;
import domain.FlightReservationComposite;
import domain.SearchFlightInformation;
import service.exception.InvalidSearchFlightException;
import service.factory.Factory;
import service.searchflightinformationservice.ISearchFlightInformationService;

/**
 * @author Brenda Palmer
 *
 */
public class SearchFlightInfoManager extends Manager {

	public SearchFlightInfoManager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static boolean searchflightresults = false;
	
	public void createSearchFlightInfo(FlightReservationComposite frc)
			throws ServiceLoadingException, InvalidSearchFlightException {

		Factory factory = Factory.getInstance();

		try {

			ISearchFlightInformationService isfis = (ISearchFlightInformationService) factory
					.getService(ISearchFlightInformationService.NAME);
			isfis.searchFlights(frc);
		} catch (ServiceLoadingException sle) {
			sle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void viewSearchFlightInfo(FlightReservationComposite frc) {

	}

	public void updateSearchFlightInfo(FlightReservationComposite frc) {

	}

	public void deleteSearchFlightInfo(FlightReservationComposite frc) {

	}

	public boolean getSearchFlightInfo(boolean searchflightresults) {

		return true;
	}

	public void generateStatement(FlightReservationComposite frc) {

	}

	public void getSearchFlightInfo(SearchFlightInformation sfi) {
		// TODO Auto-generated method stub
		
	}

}

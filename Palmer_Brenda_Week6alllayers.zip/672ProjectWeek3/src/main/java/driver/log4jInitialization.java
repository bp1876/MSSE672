package driver;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;

import org.apache.log4j.Logger;

public class log4jInitialization {

	private static Properties prop;

	public log4jInitialization() {
	}

	static Logger log = Logger.getLogger(log4jInitialization.class);

	public static void startLog() throws IOException {

		prop = new Properties();
		InputStream sf = null;

		//sf = log4jInitialization.class.getResourceAsStream("/log4j.properties");
	//	prop.load(sf);
//	    	
		//BasicConfigurator.configure();

		//PropertyConfigurator.configure(prop);

		// Log in console in and log file
		//log.info("Log4j configuration successs");
	}

	static public String getPropValue(String key) {
		if (prop == null) {
			try {
				startLog();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				log.debug("failed" + "e.printStackTrace");
			}
		}
		return prop.getProperty(key);
	}
}

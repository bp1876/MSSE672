package service.factory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import service.manager.PropertyManager;

public class PropertyXMLManager {

	static Properties prop;

	public static void loadProperties() throws ParserConfigurationException, SAXException {

		SAXParserFactory factory = SAXParserFactory.newInstance();
		javax.xml.parsers.SAXParser sax = factory.newSAXParser();

		factory.setValidating(true);

		try {

			InputStream resourceAsStream = PropertyManager.class.getResourceAsStream("/application.properties.xml");
			sax.parse(resourceAsStream, new DefaultHandler() {
				@Override
				public void startElement(String ca, String login, String keyName, Attributes at) throws SAXException {
					if (at.getValue(0) != null) {
						prop.put(keyName, at.getValue(0));
					}

				}

			});

		} catch (SAXParseException e) {
			e.printStackTrace();

		} catch (SAXException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	static public String getPropValue(String key) {
		if (prop == null) {
			prop = new Properties();
			try {
				loadProperties();
			} catch (ParserConfigurationException | SAXException e) {
				e.printStackTrace();
			}
		}
		return prop.getProperty(key);
	}
}

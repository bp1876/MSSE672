/**
 * 
 */
package service.customeraccountservice;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import domain.CustomerAccount;
import domain.FlightReservationComposite;
import driver.log4jInitialization;
import service.exception.InvalidCreditCardException;
import org.apache.log4j.Logger;


/**
 * @author Brenda Palmer
 *
 */
public class CustomerAccountJDBCImpl implements ICustomerAccountService {
	
	static Logger log = null;

	public CustomerAccountJDBCImpl() {

		Connection connect = null;
		Statement s = null;

		try {

			Class.forName("com.mysql.jdbc.Driver").newInstance();

			String userName = "root"; // don't know if this is user name for my db????
			String pasword = "password";

			String connectionURL = "jdbc:mysql://localhost/msse672";
			connect = DriverManager.getConnection(connectionURL, userName, pasword);

			s = connect.createStatement();

			String sqlInsert = "INSERT INTO customeraccount(name, address, email) VALUES('brenda', 'someplace', 'me@aol.com')";
			
			
			//s.executeUpdate(sqlInsert);

			String sqlSelect = "SELECT * FROM customeraccount";

			ResultSet rs = s.executeQuery(sqlSelect);
			
			while (rs.next()) {

				System.out.println(rs.getString(1));
			}

			

			

		} catch (SQLException sqle) {

			sqle.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Close MySQL DB Connection
		try {

			if (connect != null) {
			}

			s.close();
			connect.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	@Override
	public boolean authenticateCreditCard(FlightReservationComposite frc) throws InvalidCreditCardException {

		try {
			log4jInitialization.startLog();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		log = Logger.getLogger(CustomerAccountJDBCImpl.class);

		boolean isValid= false;

			CustomerAccount inputca = frc.getCa();
			
			String sqlSelect = "SELECT * FROM customeraccount where userName ='" + inputca.getUserName() + "' and password = '"+inputca.getPassword()+"' and email = '"+inputca.getEmail()+"';";
            System.err.println(sqlSelect);
			Connection connect = null;
			Statement s = null;

			try {

				Class.forName("com.mysql.jdbc.Driver").newInstance();

				String userName = "root"; // don't know if this is user name for my db????
				String pasword = "password";

				String connectionURL = "jdbc:mysql://localhost/msse672";
				connect = DriverManager.getConnection(connectionURL, userName, pasword);

				s = connect.createStatement();

				ResultSet rs = s.executeQuery(sqlSelect);

				while (rs.next()) { // something came up with query 
					isValid = true;
				}

			} catch (SQLException sqle) {

				sqle.printStackTrace();
				log.debug("SQLException has been thrown");
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.debug("InstantiationException has been thrown");
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.debug("IllegalAccessException has been thrown");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.debug("ClassNotFoundException has been thrown");
			}

			// Close MySQL DB Connection
			try {

				if (connect != null) {
				}

				s.close();
				connect.close();
			} catch (SQLException e) {

				e.printStackTrace();
				log.debug("SQLException has been thrown");
			}

		return isValid;
	
	}
}

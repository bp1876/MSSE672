/**
 * 
 */
package service.loginservice;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import domain.FlightReservationComposite;
import domain.Login;
import driver.log4jInitialization;
import service.exception.InvalidLoginException;

/**
 * @author Brenda Palmer
 *
 */
public class LoginORMImpl implements ILoginService {

	static Logger log = null;

	@Override
	public boolean authenticateUser(FlightReservationComposite frc) throws InvalidLoginException{

		try {
			log4jInitialization.startLog();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			log = Logger.getLogger(LoginORMImpl.class);

			Configuration config = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Login.class);

			try {

				ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(config.getProperties())
						.buildServiceRegistry();
				SessionFactory sf = config.buildSessionFactory(reg);
				Session session = sf.openSession();
				Login inputLogin = frc.getLogin();
				// Retrieves from database
				Login loginFromDbWithHibernate = (Login) session.load(Login.class, frc.getLogin().getUserName());
				System.out.println(loginFromDbWithHibernate);
				System.out.println(inputLogin);
				boolean flag = loginFromDbWithHibernate.equals(inputLogin);

				session.close();
				return flag;

			} catch (HibernateException e) {

				e.printStackTrace();
				log.debug("HibernateExecption has occured");
			}
			return false;

		}

	}


/**
 * 
 */
package service.Authentication;

import service.IAuthenticationSvc;

/**
 * @author Brenda Palmer
 *
 */
public class AuthenticationSvcSocketImpl implements IAuthenticationSvc{

}

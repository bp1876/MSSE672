/**
 * 
 */
package service.BookItineraryServiceTest;

import org.junit.jupiter.api.BeforeEach;
import org.apache.log4j.Logger;
import domain.BookItinerary;
import driver.log4jInitialization;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class BookItineraryServiceTest extends TestCase {

	static Logger log = null;
	private BookItinerary book1, book2;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	protected void setUp() throws Exception {
		super.setUp();

		book1 = new BookItinerary("true");
		book2 = new BookItinerary("true");

		log4jInitialization.startLog();
		log = Logger.getLogger(BookItineraryServiceTest.class);
	}

	/**
	 * Casting Factory output to IBookItineraryService
	 * 
	 */

	public final void testBookFlight() {

		assertTrue("book1 validates", book1.validate());

		log.info("testBookFlight Passed");
	}

	public final void testEqualsBookFlight() {

		assertTrue("book1 equals book2", book1.equals(book2));

		log.info("testEqualsBookFlight Passed");
	}
}

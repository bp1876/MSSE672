package service.BookItineraryServiceTest;

import business.exception.ServiceLoadingException;
import domain.BookItinerary;
import domain.FlightReservationComposite;
import driver.log4jInitialization;
import service.bookitineraryservice.BookItineraryImpl;
import service.bookitineraryservice.IBookItineraryService;
import service.exception.InvalidBookFlightException;
import service.factory.Factory;
import org.apache.log4j.Logger;

import junit.framework.TestCase;

public class BookItineraryImplTest extends TestCase {

	static Logger log = null;

	private Factory serviceFactory;
	private BookItinerary book;
	private FlightReservationComposite frc = new FlightReservationComposite();

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		serviceFactory = Factory.getInstance();

		book = new BookItinerary("true");
		frc.setBook(book);

		log4jInitialization.startLog();
		log = Logger.getLogger(BookItineraryImplTest.class);
	}

	public final void testBookFlight() {

		IBookItineraryService bis;

		try {
			bis = (IBookItineraryService) serviceFactory.getService(IBookItineraryService.NAME);

			assertTrue(bis.bookFlight(frc));

			log.info("testBookFlight Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadingException");
			log.debug("ServiceLoadingException");
		} catch (InvalidBookFlightException b) {
			b.printStackTrace();
			fail("InvalidBookFlightException");
			log.debug("InvalidBookFlightException");
		}

		try {

			BookItineraryImpl bii = (BookItineraryImpl) serviceFactory.getService(IBookItineraryService.NAME);

			assertTrue(bii.bookFlight(frc));

			log.info("testBookFlight Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadException");
			log.debug("ServiceLoadingException");
		} catch (InvalidBookFlightException b) {
			b.printStackTrace();
			fail("InvalidBookFlightException");
			log.debug("InvalidBookFlightException");

		}
	}
}

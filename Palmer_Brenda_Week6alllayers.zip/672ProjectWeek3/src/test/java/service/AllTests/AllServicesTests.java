/**
 * 
 */
package service.AllTests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import service.BookItineraryServiceTest.BookItineraryImplTest;
import service.BookItineraryServiceTest.BookItineraryServiceTest;
import service.CustomerAccountServiceTest.CustomerAccountImplTest;
import service.CustomerAccountServiceTest.CustomerAccountServiceTest;
import service.FactoryTest.FactoryServiceTest;
import service.ListAvailableItineraryOptionsServiceTest.ListAvailableItineraryOptionsImplTest;
import service.ListAvailableItineraryOptionsServiceTest.ListAvailableItineraryOptionsServiceTest;
import service.LoginServiceTest.LoginImplTest;
import service.LoginServiceTest.LoginServiceTest;
import service.ReserveItineraryServiceTest.ReserveItineraryImplTest;
import service.ReserveItineraryServiceTest.ReserveItineraryServiceTest;
import service.SearchFlightInformationServiceTest.SearchFlightInformationImplTest;
import service.SearchFlightInformationServiceTest.SearchFlightInformationServiceTest;




/**
 * @author Brenda Palmer
 *
 */

//The following will get all the Test classes and then execute them at once
@RunWith(Suite.class)
@SuiteClasses({ FactoryServiceTest.class, CustomerAccountServiceTest.class, LoginServiceTest.class,
		SearchFlightInformationServiceTest.class, ListAvailableItineraryOptionsServiceTest.class,
		ReserveItineraryServiceTest.class, BookItineraryServiceTest.class, CustomerAccountImplTest.class, LoginImplTest.class,
		SearchFlightInformationImplTest.class, ListAvailableItineraryOptionsImplTest.class,
		ReserveItineraryImplTest.class, BookItineraryImplTest.class})
public class AllServicesTests {

}

package service.SearchFlightInformationServiceTest;

import business.exception.ServiceLoadingException;
import domain.FlightReservationComposite;
import domain.SearchFlightInformation;
import driver.log4jInitialization;
import service.exception.InvalidSearchFlightException;
import service.factory.Factory;
import service.searchflightinformationservice.ISearchFlightInformationService;
import service.searchflightinformationservice.SearchFlightInformationImpl;
import org.apache.log4j.Logger;

import junit.framework.TestCase;

public class SearchFlightInformationImplTest extends TestCase {
	static Logger log = null;
	private Factory serviceFactory;
	private SearchFlightInformation sfi;
	private FlightReservationComposite frc = new FlightReservationComposite();

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		serviceFactory = Factory.getInstance();

		sfi = new SearchFlightInformation("031920", "5am", "DEN", "032020", "1pm", "AAA", "2", "false", "true");
		frc.setSfi(sfi);

		log4jInitialization.startLog();
		log = Logger.getLogger(SearchFlightInformationImplTest.class);
	}

	public final void testSearchFlightInformation() {

		ISearchFlightInformationService isfis;

		try {
			isfis = (ISearchFlightInformationService) serviceFactory.getService(ISearchFlightInformationService.NAME);

			assertTrue(isfis.searchFlights(frc));

			log.info("testSearchFlightInformation Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadingException");
			log.debug("ServiceLoadingException");
		} catch (InvalidSearchFlightException icce) {
			icce.printStackTrace();
			fail("InvalidSearchFlightException");
			log.debug("InvalidSearchFlightException");
		}

		try {

			SearchFlightInformationImpl s = (SearchFlightInformationImpl) serviceFactory
					.getService(ISearchFlightInformationService.NAME);

			assertTrue(s.searchFlights(frc));

			log.info("testSearchFlightInformation Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadException");
			log.debug("ServiceLoadingException");
		} catch (InvalidSearchFlightException sfe) {
			sfe.printStackTrace();
			fail("InvalidSearchFlightException");
			log.debug("InvalidSearchFlightException");

		}
	}

}

/**
 * 
 */
package domain;

import java.util.HashMap;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

/**
 * @author Brenda Palmer
 *
 */
public class LoginCollectionTest {
	
	@Test
	public void testCollection() {
		
		Login log = new Login();
		
		HashMap<String, String> result = log.getMap();
		
		Assert.assertNotNull("Map isn't null: " + result);
		

	
}
}
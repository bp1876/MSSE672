package service.customeraccountservice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;

import domain.CustomerAccount;
import domain.FlightReservationComposite;
import driver.log4jInitialization;

import service.exception.InvalidCreditCardException;

/**
 * @author Brenda Palmer
 * 
 * @param FlightReservationComposite Used to validate credit card information
 * 
 * @throws InvalidCreditCardException If credit card information is missing or
 *                                    incorrect exception will be thrown or if
 *                                    class or file is cannot be found
 *
 */

public class CustomerAccountImpl implements ICustomerAccountService {

	static Logger log = null;

	@BeforeClass
	public static void setLogger() throws Exception {
		log4jInitialization.startLog();
		log = Logger.getLogger(CustomerAccountImpl.class);
	}
	
	

	@Override
	public boolean authenticateCreditCard(FlightReservationComposite frc) throws InvalidCreditCardException {

		boolean flag = false;
		ObjectInputStream readFile = null;

		try {

			FileOutputStream fos = new FileOutputStream(
					"C:\\Users\\Admin\\git\\MSSE670\\FlightReservation\\flightdocs\\CreditCardInformation.out");
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			oos.writeObject(frc.getCa());
			oos.flush();
			oos.close();

			readFile = new ObjectInputStream(new FileInputStream(
					"C:\\Users\\Admin\\git\\MSSE670\\FlightReservation\\flightdocs\\CreditCardInformation.out"));

			Object readObject = readFile.readObject();
			CustomerAccount savedCC = CustomerAccount.class.cast(readObject);

			CustomerAccount inCC = frc.getCa();

			if (inCC != null) {

				if (savedCC.equals(inCC)) {
					flag = true;
				} else {
					flag = false;
				}

			} else {

				throw new InvalidCreditCardException("Invalid Credit Card Information Passed to CustomerAccountImpl",
						null);
			}
		} catch (FileNotFoundException fileinvalid) {

			log.debug("File not found!");
			throw new InvalidCreditCardException("File not found", fileinvalid);
		} catch (IOException e) {

			log.debug("Exception accessing file!");
			throw new InvalidCreditCardException("Exception accessing file", e);
		} catch (ClassNotFoundException classmissing) {

			log.debug("Class not found!");
			throw new InvalidCreditCardException("Class not found", classmissing);
		} finally {

			if (readFile != null) {
				try {
					readFile.close();
				} catch (IOException e) {
					// print StackTrace to screen or log
					e.printStackTrace();
				}
			}
		}

		return flag;
	}

}

package service.listavailableitineraryoptionsservice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;

import domain.FlightReservationComposite;
import domain.ListAvailableItineraryOptions;
import driver.log4jInitialization;

import service.exception.InvalidOptionsListException;

/**
 * @author Brenda Palmer
 * 
 * @param FlightReservationComposite Used to validate Options List information
 * 
 * @throws InvalidOptionsListException If options list information is missing or
 *                                     incorrect exception will be thrown or if
 *                                     class or file is cannot be found
 *
 */

public class ListAvailableItineraryOptionsImpl implements IListAvailableItineraryOptionsService {

	static Logger log = null;

	@BeforeClass
	public static void setLogger() throws Exception {
		log4jInitialization.startLog();
		log = Logger.getLogger(ListAvailableItineraryOptionsImpl.class);
	}

	@Override
	public boolean optionsList(FlightReservationComposite frc) throws InvalidOptionsListException {
		boolean flag = false;
		ObjectInputStream readFile = null;

		try {

			FileOutputStream fos = new FileOutputStream(
					"C:\\Users\\Admin\\git\\MSSE670\\FlightReservation\\flightdocs\\OptionsList.out");
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			oos.writeObject(frc.getLaio());
			oos.flush();
			oos.close();

			readFile = new ObjectInputStream(new FileInputStream(
					"C:\\Users\\Admin\\git\\MSSE670\\FlightReservation\\flightdocs\\OptionsList.out"));

			Object readObject = readFile.readObject();
			ListAvailableItineraryOptions savedList = ListAvailableItineraryOptions.class.cast(readObject);

			ListAvailableItineraryOptions inList = frc.getLaio();

			if (inList != null) {

				if (savedList.equals(inList)) {
					flag = true;
				} else {
					flag = false;
				}

			} else {

				throw new InvalidOptionsListException("Invalid Options List Information Passed to CustomerAccountImpl");
			}
		} catch (FileNotFoundException fileinvalid) {

			log.debug("File not found!");
			throw new InvalidOptionsListException("File not found", fileinvalid);
		} catch (IOException e) {

			log.debug("Exception accessing file!");
			throw new InvalidOptionsListException("Exception accessing file", e);
		} catch (ClassNotFoundException classmissing) {

			log.debug("Class not found!");
			throw new InvalidOptionsListException("Class not found", classmissing);
		} finally {

			if (readFile != null) {
				try {
					readFile.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
		}

		return flag;
	}

}

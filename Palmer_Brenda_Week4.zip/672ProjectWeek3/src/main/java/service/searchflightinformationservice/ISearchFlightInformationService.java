package service.searchflightinformationservice;

import domain.FlightReservationComposite;
import service.IService;
import service.exception.InvalidSearchFlightException;

/**
 * @author Brenda Palmer
 *
 */

//Interface for SearchFlightInformationService
public interface ISearchFlightInformationService extends IService{
	
	public final String NAME = "ISearchFlightInformationService";

	public boolean searchFlights(FlightReservationComposite frc) throws InvalidSearchFlightException;

}

package service.LoginServiceTest;

import business.exception.ServiceLoadingException;
import domain.FlightReservationComposite;
import domain.Login;
import driver.log4jInitialization;
import junit.framework.TestCase;
import service.exception.InvalidLoginException;
import service.factory.Factory;
import service.loginservice.ILoginService;

import org.apache.log4j.Logger;
import org.junit.Test;



public class LoginImplTest extends TestCase {

	static Logger log1 = null;

	private Factory serviceFactory;
	private Login login;
	private FlightReservationComposite frc = new FlightReservationComposite();

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		serviceFactory = Factory.getInstance();

		login = new Login("hibernate", "pass");
		frc.setLogin(login);

		log4jInitialization.startLog();
		log1 = Logger.getLogger(LoginImplTest.class);

	}

	
	public final void testLogin() {

		ILoginService log = null;

		try {
			log = (ILoginService) serviceFactory.getService(ILoginService.NAME);

			assertTrue(log.authenticateUser(frc));
			

			log1.info("testLogin Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadingException");
			log1.debug("ServiceLoadingException");
		} catch (InvalidLoginException icce) {
			icce.printStackTrace();
			fail("InvalidLoginException");
			log1.debug("InvalidLoginException");

		}

		ILoginService lsi = null;
		try {

			lsi = (ILoginService) serviceFactory.getService(ILoginService.NAME);

			assertTrue(lsi.authenticateUser(frc));

			log1.info("testLogin Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadException");
			log1.debug("ServiceLoadingException");
		} catch (InvalidLoginException loge) {
			loge.printStackTrace();
			fail("InvalidLoginException");
			log1.debug("InvalidLoginException");

		}
	}

}

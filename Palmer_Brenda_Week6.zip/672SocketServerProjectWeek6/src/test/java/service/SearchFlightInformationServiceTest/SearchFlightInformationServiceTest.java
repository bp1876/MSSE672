/**
 * 
 */
package service.SearchFlightInformationServiceTest;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.apache.log4j.Logger;
import domain.SearchFlightInformation;
import driver.log4jInitialization;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class SearchFlightInformationServiceTest extends TestCase {

	static Logger log = null;

	private SearchFlightInformation flightinfo1, flightinfo2;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	protected void setUp() throws Exception {
		super.setUp();

		flightinfo1 = new SearchFlightInformation("031920", "5am", "DEN", "032020", "1pm", "AAA", "2", "true", "true");
		flightinfo2 = new SearchFlightInformation("031920", "5am", "DEN", "032020", "1pm", "AAA", "2", "true", "true");

		log4jInitialization.startLog();
		log = Logger.getLogger(SearchFlightInformationServiceTest.class);
	}

	/**
	 * Casting Factory output to ISearchFlightInformationService
	 * 
	 */
	@Test
	public final void testSearchFlights() {

		assertTrue("flightinfo1 validates", flightinfo1.validate());

		log.info("testSearchFlights Passed");

	}

	@Test
	public final void testEqualsSearchFlights() {

		assertTrue("flightinfo1 equals flightinfo2", flightinfo1.equals(flightinfo2));

		log.info("testEqualsSearchFlights Passed");

	}

}

/**
 * 
 */
package business;

import javax.swing.JTextField;

import business.exception.ServiceLoadingException;
import domain.CustomerAccount;
import domain.FlightReservationComposite;
import service.customeraccountservice.ICustomerAccountService;
import service.exception.InvalidCreditCardException;
import service.factory.Factory;

/**
 * @author Brenda Palmer
 *
 */
public class CustomerAccountManager extends Manager {

	public CustomerAccountManager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static int ca = 16;

	public void createCustomerAccount(FlightReservationComposite frc)
			throws ServiceLoadingException, InvalidCreditCardException {

		Factory factory = Factory.getInstance();

		try {

			ICustomerAccountService caSvc = (ICustomerAccountService) factory.getService(ICustomerAccountService.NAME);
			caSvc.authenticateCreditCard(frc);
		} catch (ServiceLoadingException sle) {
			sle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void viewCustomerAccount(FlightReservationComposite frc) {

	}

	public void updateCustomerAccount(FlightReservationComposite frc) {

	}

	public void deleteCustomerAccount(FlightReservationComposite frc) {

	}

	public int getCustomerAccount(CustomerAccount ca2) {

		return ca;
	}

	public void generateStatement(FlightReservationComposite frc) {

	}

	public boolean getCustomerAccount(JTextField nameField, JTextField addressField, JTextField emailField,
			JTextField cc16NumField, JTextField ccExpireDateField, JTextField userNameField, JTextField passwordField) {
		// TODO Auto-generated method stub
		return true;
	}

}

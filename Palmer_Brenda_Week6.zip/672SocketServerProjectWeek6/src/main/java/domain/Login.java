package domain;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Iterator;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
@javax.persistence.Table(name = "login")
public class Login implements Serializable {

	/**
	 * The following are the class variable and instance variables. Refer to class
	 * diagram on what should be included in this class
	 */
	private static final long serialVersionUID = 1L;

	@javax.persistence.Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@javax.persistence.Column(name = "username")
	private String userName;

	@javax.persistence.Column(name = "password")
	private String password;
	
	private Long id;
	
	public Long getid() {
		
		return id;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

	/**
	 * @param userName
	 * @param password
	 * @param id
	 */
	public Login(String userName, String password, Long id) {
		super();
		this.userName = userName;
		this.password = password;
		this.id = id;
	}
	
	/**
	 * @param userName
	 * @param password
	 * @param id
	 */
	public Login(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
		
	}
	
	


	// method to authenticate the user with a valid username and valid password
	public void authenticateUser(String userName, String password) {

		HashMap<String, String> map = new HashMap<>();

		map.put(userName, password);
		map.put("a", "pass");
		map.put("tester1", "testpass");
		map.put("dev1", "devpass");

		Iterator<String> it = map.keySet().iterator();

		while (it.hasNext()) {
			String key = it.next();
			String value = map.get(key);

			System.out.println("The key is :: " + key + ", and value is :: " + value);

			map.forEach((k, v) -> System.out.println(k + " - " + v));
		}

	}

	// validate method for JUint testing
	public boolean validate() {

		if (userName == "")
			return false;
		if (password == "")
			return false;

		return true;
	}

	public Login() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Login other = (Login) obj;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Login [userName=" + userName + ", password=" + password + "]";
	}

	public static void main(String[] args) {

		HashMap<String, String> map = new HashMap<>();

		map.put("car", "pass");
		map.put("tester1", "testpass");
		map.put("dev1", "devpass");

		Iterator<String> it = map.keySet().iterator();

		while (it.hasNext()) {
			String key = it.next();
			String value = map.get(key);

			System.out.println("The key is :: " + key + ", and value is :: " + value);

			map.forEach((k, v) -> System.out.println(k + " - " + v));
		}

	}

}

package com.flightservice.server;

import java.net.ServerSocket;
import java.net.Socket;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class FlightServiceServer {

	static Logger log = Logger.getLogger("com.FlightServiceServer");

	private FlightServiceServer() {

	}

	public static void startServer() {
		try {
			log.info("Flight's Server Started");

			ServerSocket ss = new ServerSocket(8189); // port should come from a properties file

			for (;;) {
				Socket socket = ss.accept();

				FlightServiceServerHandler flightServiceServerHandler = new FlightServiceServerHandler(socket);
				flightServiceServerHandler.run();
			}
		} catch (Exception e) {
			log.error("Issue starting Flight Server ", e);
		}

	}

	public static void main(String[] args) {
		org.apache.log4j.BasicConfigurator.configure();
		Logger.getRootLogger().setLevel(Level.INFO);
		FlightServiceServer.startServer();
	}
}
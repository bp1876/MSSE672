package service.bookitineraryservice;


import domain.FlightReservationComposite;
import service.IService;
import service.exception.InvalidBookFlightException;

/**
 * @author Brenda Palmer
 *
 */
//Interface for BookItineraryService
public interface IBookItineraryService extends IService{
	
	public final String NAME = "IBookItineraryService";

	public boolean bookFlight(FlightReservationComposite frc) throws InvalidBookFlightException;

}

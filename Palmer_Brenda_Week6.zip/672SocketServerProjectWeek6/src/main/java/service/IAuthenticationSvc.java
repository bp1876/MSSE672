/**
 * 
 */
package service;

/**
 * @author Brenda Palmer
 *
 */
public interface IAuthenticationSvc {

}

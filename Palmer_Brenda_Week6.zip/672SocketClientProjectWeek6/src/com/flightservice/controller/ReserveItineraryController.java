package com.flightservice.controller;

import com.flightservice.model.domain.FlightReservationComposite;
import com.flightservice.model.domain.ReserveItinerary;

public class ReserveItineraryController implements IInterceptingController{

	public void getReserveFlight(ReserveItinerary ri) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean doAction(String cmdString, FlightReservationComposite frc) {
		// TODO Auto-generated method stub
		return false;
	}

}

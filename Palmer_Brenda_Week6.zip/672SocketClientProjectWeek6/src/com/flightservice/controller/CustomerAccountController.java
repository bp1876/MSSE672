package com.flightservice.controller;

import javax.swing.JTextField;

import com.flightservice.model.domain.FlightReservationComposite;

public class CustomerAccountController implements IInterceptingController{

	public void getCustomerAccount(JTextField nameField, JTextField addressField, JTextField emailField,
			JTextField cc16NumField, JTextField ccExpireDateField, JTextField userNameField, JTextField passwordField) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean doAction(String cmdString, FlightReservationComposite frc) {
		// TODO Auto-generated method stub
		return false;
	}

}

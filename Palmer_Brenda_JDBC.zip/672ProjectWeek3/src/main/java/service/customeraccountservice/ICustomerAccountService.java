package service.customeraccountservice;


import domain.FlightReservationComposite;
import service.IService;

import service.exception.InvalidCreditCardException;

/**
 * @author Brenda Palmer
 *
 */
// Interface for CustomerAccountService
public interface ICustomerAccountService extends IService{
	
	public final String NAME ="ICustomerAccountService";

	public boolean authenticateCreditCard(FlightReservationComposite frc) throws InvalidCreditCardException;

}

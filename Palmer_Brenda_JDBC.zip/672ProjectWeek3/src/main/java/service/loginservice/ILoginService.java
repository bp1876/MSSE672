package service.loginservice;

import domain.FlightReservationComposite;
import service.IService;
import service.exception.InvalidLoginException;

/**
 * @author Brenda Palmer
 *
 */

//Interface for LoginService
public interface ILoginService extends IService{
	
	public final String NAME = "ILoginService";

	public boolean authenticateUser(FlightReservationComposite frc) throws InvalidLoginException;

}

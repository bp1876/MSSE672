/**
 * 
 */
package service.loginservice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import domain.FlightReservationComposite;
import domain.Login;
import service.exception.InvalidLoginException;

/**
 * @author Brenda Palmer
 *
 */
public class LoginJDBCImpl implements ILoginService{

	public LoginJDBCImpl() {

		
	}

	@Override
	public boolean authenticateUser(FlightReservationComposite frc) throws InvalidLoginException {

		boolean isValid= false;

			Login inLogin = frc.getLogin();
			
			String sqlSelect = "SELECT * FROM login where username ='" + inLogin.getUserName() + "' and password = '"+inLogin.getPassword()+"';";
//            System.err.println(sqlSelect);
			Connection connect = null;
			Statement s = null;

			try {

				Class.forName("com.mysql.jdbc.Driver").newInstance();

				String userName = "root"; // don't know if this is user name for my db????
				String pasword = "password";

				String connectionURL = "jdbc:mysql://localhost/msse672";
				connect = DriverManager.getConnection(connectionURL, userName, pasword);

				s = connect.createStatement();

				ResultSet rs = s.executeQuery(sqlSelect);

				while (rs.next()) { // something came up with query 
					isValid = true;
				}

			} catch (SQLException sqle) {

				sqle.printStackTrace();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// Close MySQL DB Connection
			try {

				if (connect != null) {
				}

				s.close();
				connect.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		return isValid;
	}
}

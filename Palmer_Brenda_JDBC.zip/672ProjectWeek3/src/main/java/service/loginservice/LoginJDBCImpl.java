/**
 * 
 */
package service.loginservice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import domain.FlightReservationComposite;
import domain.Login;
import service.exception.InvalidLoginException;

/**
 * @author Brenda Palmer
 *
 */
public class LoginJDBCImpl implements ILoginService{

	public LoginJDBCImpl() {

		Connection connect = null;
		Statement s = null;

		try {

			Class.forName("com.mysql.jdbc.Driver").newInstance();

			String userName = "root"; // don't know if this is user name for my db????
			String pasword = "password";

			String connectionURL = "jdbc:mysql://localhost/msse672";
			connect = DriverManager.getConnection(connectionURL, userName, pasword);

			s = connect.createStatement();

			String sqlInsert = "INSERT INTO login(username, password) VALUES('brenda', 'pass')";
			
			s.executeUpdate(sqlInsert);
			
			
			String sqlSelect = "SELECT * FROM login";

			ResultSet rs = s.executeQuery(sqlSelect);

			

			

			while (rs.next()) {

				System.out.println(rs.getString(1));
			}

		} catch (SQLException sqle) {

			sqle.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Close MySQL DB Connection
		try {

			if (connect != null) {
			}

			s.close();
			connect.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	@Override
	public boolean authenticateUser(FlightReservationComposite frc) throws InvalidLoginException {

		boolean flag = false;
		ObjectInputStream readFile = null;

		try {

			FileOutputStream fos = new FileOutputStream(
					"C:\\Users\\Admin\\git\\MSSE670\\FlightReservation\\flightdocs\\Login.out");
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			oos.writeObject(frc.getLogin());
			oos.flush();
			oos.close();

			readFile = new ObjectInputStream(
					new FileInputStream("C:\\Users\\Admin\\git\\MSSE670\\FlightReservation\\flightdocs\\Login.out"));

			Object readObject = readFile.readObject();
			Login savedLogin = Login.class.cast(readObject);

			Login inLogin = frc.getLogin();

			if (inLogin != null) {

				if (savedLogin.equals(inLogin)) {
					flag = true;
				} else {
					flag = false;
				}

			} else {

				throw new InvalidLoginException("Invalid Login Information Passed to LoginServiceImpl");
			}

		} catch (FileNotFoundException fileinvalid) {

			throw new InvalidLoginException("File not found", fileinvalid);
		} catch (IOException e) {

			e.printStackTrace();
			throw new InvalidLoginException("Exception accessing file", e);
		} catch (ClassNotFoundException classmissing) {

			throw new InvalidLoginException("Class not found", classmissing);
		} catch (Exception e) {

			// throw new InvalidLoginException(e.getMessage());
			e.printStackTrace();
		} finally {

			if (readFile != null) {
				try {
					readFile.close();
				} catch (IOException e) {
					// print StackTrace to screen or log
					e.printStackTrace();
				}
			}
		}

		return flag;
	}
}

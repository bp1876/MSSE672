package service.ReserveItineraryServiceTest;


import org.apache.log4j.Logger;

import business.exception.ServiceLoadingException;
import domain.FlightReservationComposite;
import domain.ReserveItinerary;
import driver.log4jInitialization;
import junit.framework.TestCase;
import service.exception.InvalidReserveFlightException;
import service.factory.Factory;
import service.reserveitineraryservice.IReserveItineraryService;
import service.reserveitineraryservice.ReserveItineraryImpl;

public class ReserveItineraryImplTest extends TestCase {

	static Logger log = null;
	private Factory serviceFactory;
	private ReserveItinerary reserveflight;
	private FlightReservationComposite frc = new FlightReservationComposite();

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		serviceFactory = Factory.getInstance();

		reserveflight = new ReserveItinerary("true");
		frc.setRi(reserveflight);

		log4jInitialization.startLog();
		log = Logger.getLogger(ReserveItineraryImplTest.class);

	}

	public final void testReserveFlight() {

		IReserveItineraryService rf;

		try {
			rf = (IReserveItineraryService) serviceFactory.getService(IReserveItineraryService.NAME);

			assertTrue(rf.reserveFlight(frc));

			log.info("testReserveFlight Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadingException");
			log.debug("ServiceLoadingException");
		} catch (InvalidReserveFlightException icce) {
			icce.printStackTrace();
			fail("InvalidReserveFlightException");
			log.debug("InvalidReserveFlightException");
		}

		try {

			ReserveItineraryImpl ri = (ReserveItineraryImpl) serviceFactory.getService(IReserveItineraryService.NAME);

			assertTrue(ri.reserveFlight(frc));

			log.info("testReserveFlight Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadException");
			log.debug("ServiceLoadingException");
		} catch (InvalidReserveFlightException loge) {
			loge.printStackTrace();
			fail("InvalidReserveFlightException");
			log.debug("InvalidReserveFlightException");

		}
	}

}

/**
 * 
 */
package business;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import business.exception.ServiceLoadingException;
import domain.BookItinerary;

import service.exception.InvalidBookFlightException;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class BookItineraryMgrTest extends TestCase {

	@SuppressWarnings("unused")
	private BookItinerary book;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	protected void setUp() throws Exception {
		super.setUp();

		book = new BookItinerary("true");

	}

	@Test
	public void testgetBookItineraryInformation()
			throws ServiceLoadingException, InvalidBookFlightException, IOException {

		assertTrue(Manager.class.isAssignableFrom(BookItineraryManager.class));
		System.out.println(BookItineraryManager.flightBooked);
		System.out.println("testgetBookItineraryInformation Passed");

	}

}

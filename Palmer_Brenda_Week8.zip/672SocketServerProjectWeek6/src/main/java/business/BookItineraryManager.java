/**
 * 
 */
package business;

import business.exception.ServiceLoadingException;
import domain.BookItinerary;
import domain.FlightReservationComposite;
import service.bookitineraryservice.IBookItineraryService;
import service.exception.InvalidBookFlightException;
import service.factory.Factory;

/**
 * @author Brenda Palmer
 *
 */
public class BookItineraryManager extends Manager{

	
	public BookItineraryManager() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static boolean flightBooked = false;

	public void createBookItinerary(FlightReservationComposite frc)
			throws ServiceLoadingException, InvalidBookFlightException {

		Factory factory = Factory.getInstance();

		try {

			IBookItineraryService b = (IBookItineraryService) factory.getService(IBookItineraryService.NAME);
			b.bookFlight(frc);
		} catch (ServiceLoadingException sle) {
			sle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void viewBookItinerary(FlightReservationComposite frc) {

	}

	public void updateBookItinerary(FlightReservationComposite frc) {

	}

	public void deleteBookItinerary(FlightReservationComposite frc) {

	}

	public boolean getBookItinerary(BookItinerary book) {

		return true;
	}

	public void generateStatement(FlightReservationComposite frc) {

	}
	
	

}

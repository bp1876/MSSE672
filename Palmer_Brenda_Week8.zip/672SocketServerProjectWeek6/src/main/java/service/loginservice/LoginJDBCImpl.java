/**
 * 
 */
package service.loginservice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import domain.FlightReservationComposite;
import domain.Login;
import driver.log4jInitialization;
import service.exception.InvalidLoginException;
import org.apache.log4j.Logger;

/**
 * @author Brenda Palmer
 *
 */
public class LoginJDBCImpl implements ILoginService {

	static Logger log = null;

	public LoginJDBCImpl() {

	}

	@Override
	public boolean authenticateUser(FlightReservationComposite frc) throws InvalidLoginException {

		try {
			log4jInitialization.startLog();
		} catch (IOException e1) {
			log.debug("Error initializing log4j");
			e1.printStackTrace();
		}
		log = Logger.getLogger(LoginJDBCImpl.class);

		boolean isValid = false;

		Login inLogin = frc.getLogin();

		String sqlSelect = "SELECT * FROM login where username ='" + inLogin.getUserName() + "' and password = '"
				+ inLogin.getPassword() + "';";
//            System.err.println(sqlSelect);
		Connection connect = null;
		Statement s = null;

		Properties dbProps = new Properties();

		try {

			FileInputStream is = null;
			try {
				is = new FileInputStream(
						"C:\\Users\\Admin\\eclipse-workspace\\672ProjectWeek3\\src\\main\\resources\\db.properties");
			} catch (FileNotFoundException e) {
				log.debug("db.properties file not found");
				e.printStackTrace();
			}
			dbProps.load(is);

			Class.forName(dbProps.getProperty("db.driver"));
			connect = DriverManager.getConnection(dbProps.getProperty("db.url"), dbProps.getProperty("db.user"),
					dbProps.getProperty("db.password"));
			
			PreparedStatement ps = connect.prepareStatement(sqlSelect);

				
			int update = ps.executeUpdate();
			
			System.out.println("ExecuteUpdate " + update);

		
		} catch (SQLException sqle) {

			sqle.printStackTrace();
			log.debug("SQLException has been thrown");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.debug("ClassNotFoundException has been thrown");
		} catch (IOException e) {
			log.debug("db.properties file did not load");
			e.printStackTrace();
		}

		// Close MySQL DB Connection
		try {

			if (connect != null) {
			}

			s.close();
			connect.close();
		} catch (SQLException e) {

			e.printStackTrace();
			log.debug("SQLException has been thrown");
		}

		return isValid;
	}
}

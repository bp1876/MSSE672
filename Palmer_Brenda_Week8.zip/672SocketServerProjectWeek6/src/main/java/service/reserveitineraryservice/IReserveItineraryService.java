package service.reserveitineraryservice;

import domain.FlightReservationComposite;
import service.IService;
import service.exception.InvalidReserveFlightException;

/**
 * @author Brenda Palmer
 *
 */

//Interface for ReserveItineraryService
public interface IReserveItineraryService extends IService{
	
	public final String NAME = "IReserveItineraryService";

	public boolean reserveFlight(FlightReservationComposite frc) throws InvalidReserveFlightException;

}

package service.listavailableitineraryoptionsservice;

import domain.FlightReservationComposite;
import service.IService;
import service.exception.InvalidOptionsListException;

/**
 * @author Brenda Palmer
 *
 */
//Interface for ListAvailableItineraryOptionsService
public interface IListAvailableItineraryOptionsService extends IService{
	
	public final String NAME = "IListAvailableItineraryOptionsService";

	public boolean optionsList(FlightReservationComposite frc) throws InvalidOptionsListException;

}

package com.flightservice.server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;

import business.LoginManager;
import domain.FlightReservationComposite;
import service.factory.Factory;

//The FlightServiceServerHandler class is a message queue processor

@Controller
public class FlightServiceServerHandler implements Runnable {

	protected static Socket inSocket;
	private int threadCount;
	
	public FlightServiceServerHandler(Socket _inSocket) {
		inSocket = _inSocket;
	}


	public FlightServiceServerHandler(int i) {
		this.threadCount = 0;
		// TODO Auto-generated constructor stub
	}

	static Logger log = Logger.getLogger("com.FlightService");
	
	
	//This method processes the incoming and outgoing messages
	@Bean
	public void run() {
		
		//Spring code
		ApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"springconfig.xml"});
		
		LoginManager loginmgr = (LoginManager) context.getBean("Loginmgr");
		System.err.println("Login manager successfully created-->" + loginmgr.getClass());
		loginmgr.getLogin("brenda", "pass");
		
		
		ObjectInputStream in = null;
		ObjectOutputStream out = null;

		try {
			in = new ObjectInputStream(inSocket.getInputStream());
			out = new ObjectOutputStream(inSocket.getOutputStream());

			String cmdString = (String) in.readObject();

			log.info("Flight Service ServerHandler::run:Received command to execute service: " + cmdString);
			
		
			boolean status = true;

			
			out.writeObject(status);

			out.flush();

		} catch (Exception e) {
			log.error("Error processing request from client", e);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
				if (out != null) {
					out.close();
				}
				if (inSocket != null) {
					inSocket.close();
				}
			} catch (IOException e) {
				log.error(e.getClass() + ": " + e.getMessage(), e);
			}
		}
	}
}
package com.flightservice.server;

import java.io.FileReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.SocketChannel;
import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;


//This class invokes the FlightServiceHandler by creating an open port to communicate with
//the clients
public class FlightServiceServer extends FlightServiceServerHandler {

	public FlightServiceServer(int threadCount) {
		super(threadCount);
		// TODO Auto-generated constructor stub
	}

	static Logger log = Logger.getLogger("com.FlightServiceServer");
	private static int threadCount = 1;
	static Socket socket = null;

	//This starts the server running so it can listen for clients
	public static void startServer() {
		try {
			log.info("Flight's Server Started");

			Properties config = new Properties();

			config.load(new FileReader(
					"system.properties")); //-Dsystemconfig=C:\Users\Admin\eclipse-workspace\672SocketServerProjectWeek6\src\main\resources\system.properties
			

			int port = Integer.parseInt(config.getProperty("port"));

			ServerSocket ss = new ServerSocket(port);

			for (;;) {
				socket = ss.accept();

				FlightServiceServerHandler fssh = new FlightServiceServerHandler(socket);
				fssh.run();
				log.info("Threads created: " + threadCount);

				threadCount++;
			}

		} catch (Exception e) {
			log.error("Issue starting Flight Server ", e);
		}

	}

	//Main method to invoke threads
	public static void main(String[] args) {
		org.apache.log4j.BasicConfigurator.configure();
		Logger.getRootLogger().setLevel(Level.INFO);

		FlightServiceServerHandler t = new FlightServiceServerHandler(1);

		FlightServiceServerHandler t2 = new FlightServiceServerHandler(2);

		System.out.println("Main thread: " + t);
		System.out.println("Second thread: " + t2);
		t.run();
		FlightServiceServer.startServer();
		
		

	}

}
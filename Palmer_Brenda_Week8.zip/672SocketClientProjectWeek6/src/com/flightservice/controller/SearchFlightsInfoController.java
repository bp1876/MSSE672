package com.flightservice.controller;

import com.flightservice.model.domain.FlightReservationComposite;
import com.flightservice.model.domain.SearchFlightInformation;

public class SearchFlightsInfoController implements IInterceptingController{

	public void getSearchFlightInfo(SearchFlightInformation sfi) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean doAction(String cmdString, FlightReservationComposite frc) {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}

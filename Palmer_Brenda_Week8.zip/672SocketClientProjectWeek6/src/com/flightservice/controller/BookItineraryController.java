package com.flightservice.controller;

import com.flightservice.model.domain.BookItinerary;
import com.flightservice.model.domain.FlightReservationComposite;

public class BookItineraryController implements IInterceptingController{

	public void getBookItinerary(BookItinerary book) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean doAction(String cmdString, FlightReservationComposite frc) {
		// TODO Auto-generated method stub
		return false;
	}

}

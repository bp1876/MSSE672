package com.flightservice.controller;

import com.flightservice.model.domain.FlightReservationComposite;
import com.flightservice.model.domain.ListAvailableItineraryOptions;

public class ListAvailableItineraryOptionsController implements IInterceptingController{

	public void getListOptions(ListAvailableItineraryOptions laio) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean doAction(String cmdString, FlightReservationComposite frc) {
		// TODO Auto-generated method stub
		return false;
	}

}

package com.flightservice.controller;

import com.flightservice.model.domain.FlightReservationComposite;

public interface IInterceptingController {
	
	public boolean doAction(String cmdString, FlightReservationComposite frc);

	
}

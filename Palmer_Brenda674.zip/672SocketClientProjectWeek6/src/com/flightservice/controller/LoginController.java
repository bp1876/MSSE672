package com.flightservice.controller;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Logger;

import javax.swing.JTextField;

import com.flightservice.model.domain.FlightReservationComposite;


//This class takes the domain objects and passes them from the client to the server
public class LoginController implements IInterceptingController {

	static Logger log = Logger.getLogger("com.FlightServiceClient");
	
	//gets the JTextFields objects
	public void getLogin(JTextField userNameField, JTextField passwordField) {

	}

	//This allows the domain objects to flow in and out of the controller from the client to the server
	@Override
	public boolean doAction(String cmdString, FlightReservationComposite frc) {
		boolean status = false;
		Socket socket = null;
		ObjectOutputStream out = null;
		ObjectInputStream in = null;

		try {
			System.out.println("Preparing socket server connection");

			socket = new Socket(InetAddress.getLocalHost(), 8189);

			out = new ObjectOutputStream(socket.getOutputStream());
			out.flush();

			out.writeObject("LoginService");
			out.writeObject(cmdString);
			out.writeObject(frc);

			in = new ObjectInputStream(socket.getInputStream());
			status = (Boolean) in.readObject();
			frc = (FlightReservationComposite) in.readObject();

		} catch (Exception e) {
			e.printStackTrace();
			log.info(e.getClass() + ": " + e.getMessage());
		}

		finally {

			try {
				if (in != null) {
					in.close();
				}
				if (out != null) {
					out.close();
				}
				if (socket != null) {
					socket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
				log.info(e.getClass() + ": " + e.getMessage());
				
			}
		}
		return status;
	}

}

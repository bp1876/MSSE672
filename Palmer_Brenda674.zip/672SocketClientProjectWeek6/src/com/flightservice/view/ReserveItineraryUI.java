package com.flightservice.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.flightservice.controller.ReserveItineraryController;
import com.flightservice.model.domain.ReserveItinerary;

@SuppressWarnings("serial")
public class ReserveItineraryUI extends JInternalFrame {

	private JFrame frmReserveitinerary;
	private JTextField selectListField;

	/**
	 * Launch the application.
	 */
	public void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReserveItineraryUI window = new ReserveItineraryUI();
					window.frmReserveitinerary.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ReserveItineraryUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmReserveitinerary = new JFrame();
		frmReserveitinerary.setTitle("ReserveItinerary");
		frmReserveitinerary.setBounds(100, 100, 450, 300);
		frmReserveitinerary.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmReserveitinerary.getContentPane().setLayout(null);

		JLabel selectListLabel = new JLabel("Enter Yes to select the list to Reserve Flight");
		selectListLabel.setHorizontalAlignment(SwingConstants.LEFT);
		selectListLabel.setBounds(10, 56, 274, 14);
		frmReserveitinerary.getContentPane().add(selectListLabel);

		selectListField = new JTextField();
		selectListField.setHorizontalAlignment(SwingConstants.LEFT);
		selectListField.setBounds(294, 53, 86, 20);
		frmReserveitinerary.getContentPane().add(selectListField);
		selectListField.setColumns(10);

		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			// Create Inner class
			@Override
			public void actionPerformed(ActionEvent e) {

				ReserveItinerary ri = new ReserveItinerary();
				ri.reserveFlight(selectListField.getText());
				ReserveItineraryController rim = new ReserveItineraryController();
				rim.getReserveFlight(ri);

				// Show GUI message to user for validation
				if (selectListField.getText().equals("")) {

					JOptionPane.showMessageDialog(frmReserveitinerary, "Itineary not Rerserved, please try again");
				} else {

					JOptionPane.showMessageDialog(frmReserveitinerary,
							"Itinerary successfully reservered, proceed to book the itinerary");
				}

			}

		});

		btnSubmit.setBounds(225, 187, 89, 23);
		frmReserveitinerary.getContentPane().add(btnSubmit);

		pack();
		setVisible(true);
	}

}

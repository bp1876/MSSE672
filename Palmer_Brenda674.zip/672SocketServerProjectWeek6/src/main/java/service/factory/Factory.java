package service.factory;


import business.exception.ServiceLoadingException;
import domain.FlightReservationComposite;
import service.IService;
import service.manager.PropertyManager;

/**
 * @author Brenda Palmer
 *
 */

public class Factory {

	/**
	 * Singleton Pattern
	 */

	public Factory() {
	}

	private static Factory factory = new Factory();

	public static Factory getInstance() {
		return factory;
	}

	@SuppressWarnings("deprecation")
	public IService getService(String svcName) throws ServiceLoadingException {

		try {
			Class<?> c = Class.forName(getImplName(svcName));
			return (IService) c.newInstance();
		} catch (Exception e) {
			svcName = svcName + "service unable to load";
			e.printStackTrace();
			throw new ServiceLoadingException(svcName, e);
		}

	}

	/**
	 * 
	 * @param svcName
	 * @return
	 * @throws Exception
	 */

	private String getImplName(String svcName) throws Exception {
	return PropertyFactory.getPropValue(svcName,"XML");

	}

	public boolean performAction(String cmdString, FlightReservationComposite frc) {
		// TODO Auto-generated method stub
		return false;
	}
}

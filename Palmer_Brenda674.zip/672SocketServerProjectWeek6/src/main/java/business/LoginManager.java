/**
 * 
 */
package business;

import javax.swing.JTextField;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import business.exception.ServiceLoadingException;
import domain.FlightReservationComposite;
import service.exception.InvalidLoginException;
import service.factory.Factory;
import service.loginservice.ILoginService;

/**
 * @author Brenda Palmer
 *
 */
@Component
public class LoginManager extends Manager {
	
	//Private method for Spring
	private ILoginService iloginsvc;
	
	

	

	/**
	 * @param Inject Spring
	 * @return 
	 */
	@Autowired
	public static String setUserName(String userName) {
		return LoginManager.userName = userName;
	}

	

	/**
	 * @param Inject Spring
	 * @return 
	 */
	@Autowired
	public static String setPassword(String password) {
		return LoginManager.password = password;
	}

	public LoginManager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static String userName = "brenda";
	public static String password = "pass";

	public void createLogin(FlightReservationComposite frc) throws ServiceLoadingException, InvalidLoginException {

		Factory factory = Factory.getInstance();

		try {
			ILoginService ls = (ILoginService) factory.getService(ILoginService.NAME);
			ls.authenticateUser(frc);
		} catch (ServiceLoadingException sle) {
			sle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void viewLogin(FlightReservationComposite frc) {

	}

	public void updateLogin(FlightReservationComposite frc) {

	}

	public void deleteLogin(FlightReservationComposite frc) {

	}

	public String getLogin(String userName, String password) {

		return userName + password;
	}

	public void generateStatement(FlightReservationComposite frc) {

	}

	public void getLogin(JTextField userNameField, JTextField passwordField) {
		// TODO Auto-generated method stub
		
	}


	//Getter for Spring
	public ILoginService getIloginsvc() {
		return iloginsvc;
	}


	//Setter for Spring
	public void setIloginsvc(ILoginService iloginsvc) {
		this.iloginsvc = iloginsvc;
	}

}

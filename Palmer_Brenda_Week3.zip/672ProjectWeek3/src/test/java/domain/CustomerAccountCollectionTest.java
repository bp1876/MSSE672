/**
 * 
 */
package domain;


import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

/**
 * @author Brenda Palmer
 *
 */
public class CustomerAccountCollectionTest {

	
	@Test
	public void testCollection() {
		
		CustomerAccount ca = new CustomerAccount();
		List<String> result = ca.registerCustomer();
		
		Assert.assertNotNull("List isn't empty: " + result);
		Assert.assertEquals("name", result.get(0));
		
		
	}

	
}

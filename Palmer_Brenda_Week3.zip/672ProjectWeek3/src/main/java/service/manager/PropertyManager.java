package service.manager;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyManager {

	private static Properties prop;

	public static void loadProperties() throws IOException {
		prop = new Properties();
		InputStream sf = null;

		sf = PropertyManager.class.getResourceAsStream("/application.properties");
		prop.load(sf);
	}

	static public String getPropValue(String key) {
		if (prop == null) {
			try {
				loadProperties();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
		return prop.getProperty(key);
	}
}

package service.factory;

import business.exception.ServiceLoadingException;

import service.manager.PropertyManager;
import service.IService;

/**
 * @author Brenda Palmer
 *
 */

public class Factory {

	/**
	 * Singleton Pattern
	 */

	public Factory() {
	}

	private static Factory factory = new Factory();

	public static Factory getInstance() {
		return factory;
	}

	@SuppressWarnings("deprecation")
	public IService getService(String svcName) throws ServiceLoadingException {

		try {
			Class<?> c = Class.forName(getImplName(svcName));
			return (IService) c.newInstance();
		} catch (Exception e) {
			svcName = svcName + "service unable to load";
			e.printStackTrace();
			throw new ServiceLoadingException(svcName, e);
		}

	}

	/**
	 * 
	 * @param svcName
	 * @return
	 * @throws Exception
	 */

	private String getImplName(String svcName) throws Exception {

		return PropertyManager.getPropValue(svcName);

	}
}

/**
 * 
 */
package service.loginservice;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import domain.FlightReservationComposite;
import domain.Login;
import driver.log4jInitialization;
import service.exception.InvalidLoginException;
import org.apache.log4j.Logger;

/**
 * @author Brenda Palmer
 *
 */
public class LoginJDBCImpl implements ILoginService{

	static Logger log = null;
	
	
	
	public LoginJDBCImpl() {

		
		
	}
	
	

	@Override
	public boolean authenticateUser(FlightReservationComposite frc) throws InvalidLoginException {

		try {
			log4jInitialization.startLog();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		log = Logger.getLogger(LoginJDBCImpl.class);
		
		boolean isValid= false;

			Login inLogin = frc.getLogin();
			
			String sqlSelect = "SELECT * FROM login where username ='" + inLogin.getUserName() + "' and password = '"+inLogin.getPassword()+"';";
//            System.err.println(sqlSelect);
			Connection connect = null;
			Statement s = null;

			try {
				
				

				Class.forName("com.mysql.jdbc.Driver").newInstance();

				String userName = "root"; // don't know if this is user name for my db????
				String pasword = "password";

				String connectionURL = "jdbc:mysql://localhost/msse672";
				connect = DriverManager.getConnection(connectionURL, userName, pasword);

				s = connect.createStatement();

				ResultSet rs = s.executeQuery(sqlSelect);

				while (rs.next()) { // something came up with query 
					isValid = true;
				}

			} catch (SQLException sqle) {

				sqle.printStackTrace();
				log.debug("SQLException has been thrown");
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.debug("InstantiationException has been thrown");
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.debug("IllegalAccessException has been thrown");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.debug("ClassNotFoundException has been thrown");
			}

			// Close MySQL DB Connection
			try {

				if (connect != null) {
				}

				s.close();
				connect.close();
			} catch (SQLException e) {

				e.printStackTrace();
				log.debug("SQLException has been thrown");
			}

		return isValid;
	}
}

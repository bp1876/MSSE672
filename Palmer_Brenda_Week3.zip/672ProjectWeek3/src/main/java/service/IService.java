/**
 * 
 */
package service;

/**
 * @author Brenda Palmer
 * 
 * Marker Interface
 *
 */
public interface IService {
	
	
}

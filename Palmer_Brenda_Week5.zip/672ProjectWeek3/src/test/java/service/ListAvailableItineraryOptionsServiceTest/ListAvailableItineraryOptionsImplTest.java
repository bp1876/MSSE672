package service.ListAvailableItineraryOptionsServiceTest;


import business.exception.ServiceLoadingException;
import domain.FlightReservationComposite;
import domain.ListAvailableItineraryOptions;
import driver.log4jInitialization;
import service.exception.InvalidOptionsListException;
import service.factory.Factory;
import service.listavailableitineraryoptionsservice.IListAvailableItineraryOptionsService;
import service.listavailableitineraryoptionsservice.ListAvailableItineraryOptionsImpl;
import org.apache.log4j.Logger;
import junit.framework.TestCase;

public class ListAvailableItineraryOptionsImplTest extends TestCase {

	static Logger log = null;

	private Factory serviceFactory;
	private ListAvailableItineraryOptions optionsList;
	private FlightReservationComposite frc = new FlightReservationComposite();

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		serviceFactory = Factory.getInstance();

		optionsList = new ListAvailableItineraryOptions("500.99", "1", "1");
		frc.setLaio(optionsList);

		log4jInitialization.startLog();
		log = Logger.getLogger(ListAvailableItineraryOptionsImplTest.class);
	}

	public final void testOptionsList() {

		IListAvailableItineraryOptionsService ilaios;

		try {
			ilaios = (IListAvailableItineraryOptionsService) serviceFactory
					.getService(IListAvailableItineraryOptionsService.NAME);

			assertTrue(ilaios.optionsList(frc));

			log.info("testOptionsList Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadingException");
			log.debug("ServiceLoadingException");
		} catch (InvalidOptionsListException icce) {
			icce.printStackTrace();
			fail("InvalidOptionsListException");
			log.debug("InvalidOptionsListException");
		}

		try {

			ListAvailableItineraryOptionsImpl l = (ListAvailableItineraryOptionsImpl) serviceFactory
					.getService(IListAvailableItineraryOptionsService.NAME);

			assertTrue(l.optionsList(frc));

			log.info("testOptionsList Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadException");
			log.debug("ServiceLoadingException");
		} catch (InvalidOptionsListException ole) {
			ole.printStackTrace();
			fail("InvalidOptionsListException");
			log.debug("InvalidOptionsListException");

		}
	}

}

/**
 * 
 */
package service.ListAvailableItineraryOptionsServiceTest;

import org.junit.jupiter.api.BeforeEach;
import org.apache.log4j.Logger;
import domain.ListAvailableItineraryOptions;
import driver.log4jInitialization;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class ListAvailableItineraryOptionsServiceTest extends TestCase {

	static Logger log = null;

	private ListAvailableItineraryOptions optionsList1, optionsList2;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	protected void setUp() throws Exception {
		super.setUp();

		optionsList1 = new ListAvailableItineraryOptions("500.99", "1", "1");
		optionsList2 = new ListAvailableItineraryOptions("500.99", "1", "1");

		log4jInitialization.startLog();
		log = Logger.getLogger(ListAvailableItineraryOptionsServiceTest.class);
	}

	/**
	 * Casting Factory output to IListAvailableItineraryOptionsService
	 * 
	 */
	public final void testListOptions() {

		assertTrue("optionsList1 validates", optionsList1.validate());

		log.info("testListOptions Passed");

	}

	public final void testEqualsListOptions() {

		assertTrue("optionsList1 equals optionsList1", optionsList1.equals(optionsList2));

		log.info("testListOptions Passed");

	}
}

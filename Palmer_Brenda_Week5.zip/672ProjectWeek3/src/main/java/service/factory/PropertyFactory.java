package service.factory;

import org.xml.sax.helpers.DefaultHandler;

import service.manager.PropertyManager;

public class PropertyFactory extends DefaultHandler {

	public static String getPropValue(String svcName, String string) {
		if (string.equalsIgnoreCase("XML")) {
			return PropertyXMLManager.getPropValue(svcName);
		} else {
			return PropertyManager.getPropValue(svcName);
		}
	}

}

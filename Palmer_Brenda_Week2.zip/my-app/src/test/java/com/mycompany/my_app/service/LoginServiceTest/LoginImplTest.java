package com.mycompany.my_app.service.LoginServiceTest;

import business.exception.ServiceLoadingException;
import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.domain.Login;
import com.mycompany.my_app.driver.log4jInitialization;
import com.mycompany.my_app.service.exception.InvalidLoginException;
import com.mycompany.my_app.service.factory.Factory;
import com.mycompany.my_app.service.loginservice.ILoginService;
import com.mycompany.my_app.service.loginservice.LoginServiceImpl;
import org.apache.log4j.Logger;

import junit.framework.TestCase;

public class LoginImplTest extends TestCase {

	static Logger log1 = null;

	private Factory serviceFactory;
	private Login login;
	private FlightReservationComposite frc = new FlightReservationComposite();

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		serviceFactory = Factory.getInstance();

		login = new Login("brenda", "pass");
		frc.setLogin(login);

		log4jInitialization.startLog();
		log1 = Logger.getLogger(LoginImplTest.class);

	}

	public final void testLogin() {

		ILoginService log = null;

		try {
			log = (ILoginService) serviceFactory.getService(ILoginService.NAME);

			assertTrue(log.authenticateUser(frc));

			log1.info("testLogin Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadingException");
			log1.debug("ServiceLoadingException");
		} catch (InvalidLoginException icce) {
			icce.printStackTrace();
			fail("InvalidLoginException");
			log1.debug("InvalidLoginException");

		}

		LoginServiceImpl lsi = null;
		try {

			lsi = (LoginServiceImpl) serviceFactory.getService(ILoginService.NAME);

			assertTrue(lsi.authenticateUser(frc));

			log1.info("testLogin Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadException");
			log1.debug("ServiceLoadingException");
		} catch (InvalidLoginException loge) {
			loge.printStackTrace();
			fail("InvalidLoginException");
			log1.debug("InvalidLoginException");

		}
	}

}

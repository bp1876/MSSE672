package com.mycompany.my_app.service.LoginServiceTest;

import java.io.IOException;

import org.apache.log4j.Logger;

import org.junit.jupiter.api.BeforeEach;

import com.mycompany.my_app.domain.Login;
import com.mycompany.my_app.driver.log4jInitialization;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */

public class LoginServiceTest extends TestCase {

	static Logger log = null;

	private Login login1, login2;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	protected void setUp() throws Exception {
		super.setUp();

		login1 = new Login("brenda", "pass");
		login2 = new Login("brenda", "pass");
		log4jInitialization.startLog();
		log = Logger.getLogger(LoginServiceTest.class);

	}

	/**
	 * Casting Factory output to ILoginService
	 * 
	 * @throws IOException
	 * 
	 */
	public final void testauthenticateUser() throws IOException {

		assertTrue("Login validates", login1.validate());

		log.info("testauthenticateUser Passed");

	}

	public final void testEqualsAuthenticateUser() throws IOException {

		assertTrue("login1 equals login2", login1.equals(login2));

		log.info("testEqualsAuthenticateUser Passed");
	}
}

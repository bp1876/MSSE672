/**
 * 
 */
package com.mycompany.my_app.domain;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

/**
 * @author Brenda Palmer
 *
 */
public class CustomerAccountCollectionTest {

	
	@Test
	public void testCollection() {
		
		CustomerAccount ca = new CustomerAccount();
		List<String> result = ca.registerCustomer();
		
		Assert.assertNotNull("List isn't empty: " + result);
		Assert.assertEquals("name", result.get(0));
		
		
	}

	
}

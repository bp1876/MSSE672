package com.mycompany.my_app.service.ListAvailableItineraryOptionsServiceTest;

import business.exception.ServiceLoadingException;
import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.domain.ListAvailableItineraryOptions;
import com.mycompany.my_app.driver.log4jInitialization;
import com.mycompany.my_app.service.exception.InvalidOptionsListException;
import com.mycompany.my_app.service.factory.Factory;
import com.mycompany.my_app.service.listavailableitineraryoptionsservice.IListAvailableItineraryOptionsService;
import com.mycompany.my_app.service.listavailableitineraryoptionsservice.ListAvailableItineraryOptionsImpl;
import org.apache.log4j.Logger;

import junit.framework.TestCase;

public class ListAvailableItineraryOptionsImplTest extends TestCase {

	static Logger log = null;

	private Factory serviceFactory;
	private ListAvailableItineraryOptions optionsList;
	private FlightReservationComposite frc = new FlightReservationComposite();

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		serviceFactory = Factory.getInstance();

		optionsList = new ListAvailableItineraryOptions("500.99", "1", "1");
		frc.setLaio(optionsList);

		log4jInitialization.startLog();
		log = Logger.getLogger(ListAvailableItineraryOptionsImplTest.class);
	}

	public final void testOptionsList() {

		IListAvailableItineraryOptionsService ilaios;

		try {
			ilaios = (IListAvailableItineraryOptionsService) serviceFactory
					.getService(IListAvailableItineraryOptionsService.NAME);

			assertTrue(ilaios.optionsList(frc));

			log.info("testOptionsList Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadingException");
			log.debug("ServiceLoadingException");
		} catch (InvalidOptionsListException icce) {
			icce.printStackTrace();
			fail("InvalidOptionsListException");
			log.debug("InvalidOptionsListException");
		}

		try {

			ListAvailableItineraryOptionsImpl l = (ListAvailableItineraryOptionsImpl) serviceFactory
					.getService(IListAvailableItineraryOptionsService.NAME);

			assertTrue(l.optionsList(frc));

			log.info("testOptionsList Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadException");
			log.debug("ServiceLoadingException");
		} catch (InvalidOptionsListException ole) {
			ole.printStackTrace();
			fail("InvalidOptionsListException");
			log.debug("InvalidOptionsListException");

		}
	}

}

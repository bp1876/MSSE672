/**
 * 
 */
package com.mycompany.my_app.service.FactoryTest;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import business.exception.ServiceLoadingException;
import com.mycompany.my_app.service.bookitineraryservice.IBookItineraryService;
import com.mycompany.my_app.service.customeraccountservice.ICustomerAccountService;
import com.mycompany.my_app.service.factory.Factory;
import com.mycompany.my_app.service.listavailableitineraryoptionsservice.IListAvailableItineraryOptionsService;
import com.mycompany.my_app.service.loginservice.ILoginService;
import com.mycompany.my_app.service.reserveitineraryservice.IReserveItineraryService;
import com.mycompany.my_app.service.searchflightinformationservice.ISearchFlightInformationService;

/**
 * @author Brenda Palmer
 *
 */
public class FactoryServiceTest {

	Factory serviceFactory;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

		serviceFactory = new Factory();
	}

	@Test
	public void testauthenticateCreditCard() {

		@SuppressWarnings("unused")
		ICustomerAccountService icas;
		try {
			icas = (ICustomerAccountService) serviceFactory.getService(ICustomerAccountService.NAME);
			System.out.println("testauthenticateCreditCard Passed");
		} catch (ServiceLoadingException e) {

			fail("ServiceLoadingException");
		}

	}

	@Test
	public void testauthenticateUser() {

		@SuppressWarnings("unused")
		ILoginService ils;

		try {
			ils = (ILoginService) serviceFactory.getService(ILoginService.NAME);
			System.out.println("testauthenticateUser Passed");
		} catch (ServiceLoadingException e) {

			e.printStackTrace();
			fail("ServiceLoadingException");
		}
	}

	@Test
	public void testSearchFlights() {

		@SuppressWarnings("unused")
		ISearchFlightInformationService isfis;
		try {
			isfis = (ISearchFlightInformationService) serviceFactory.getService(ISearchFlightInformationService.NAME);
			System.out.println("testSearchFlights Passed");
		} catch (ServiceLoadingException e) {

			e.printStackTrace();
			fail("ServiceLoadingException");
		}
	}

	@Test
	public void testListOptions() {

		@SuppressWarnings("unused")
		IListAvailableItineraryOptionsService ilaios;

		try {
			ilaios = (IListAvailableItineraryOptionsService) serviceFactory
					.getService(IListAvailableItineraryOptionsService.NAME);
			System.out.println("testListOptions Passed");
		} catch (ServiceLoadingException e) {

			e.printStackTrace();
			fail("ServiceLoadingException");
		}
	}

	@Test
	public void testReserveItinerary() {

		@SuppressWarnings("unused")
		IReserveItineraryService iris;

		try {
			iris = (IReserveItineraryService) serviceFactory.getService(IReserveItineraryService.NAME);
			System.out.println("testReserveItinerary Passed");
		} catch (ServiceLoadingException e) {

			e.printStackTrace();
			fail("ServiceLoadingException");
		}
	}

	@Test
	public void testBookItinerary() {

		@SuppressWarnings("unused")
		IBookItineraryService ibis;

		try {
			ibis = (IBookItineraryService) serviceFactory.getService(IBookItineraryService.NAME);
			System.out.println("testBookItinerary Passed");
		} catch (ServiceLoadingException e) {

			e.printStackTrace();
			fail("ServiceLoadingException");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}

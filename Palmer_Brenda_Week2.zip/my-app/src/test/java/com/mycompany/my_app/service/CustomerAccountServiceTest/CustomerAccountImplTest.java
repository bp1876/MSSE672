/**
 * 
 */
package com.mycompany.my_app.service.CustomerAccountServiceTest;

import business.exception.ServiceLoadingException;
import com.mycompany.my_app.domain.CustomerAccount;
import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.driver.log4jInitialization;
import com.mycompany.my_app.service.customeraccountservice.CustomerAccountImpl;
import com.mycompany.my_app.service.customeraccountservice.ICustomerAccountService;
import com.mycompany.my_app.service.exception.InvalidCreditCardException;
import com.mycompany.my_app.service.factory.Factory;
import org.apache.log4j.Logger;
import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class CustomerAccountImplTest extends TestCase {

	static Logger log = null;

	private Factory serviceFactory;
	private CustomerAccount ca;
	private FlightReservationComposite frc = new FlightReservationComposite();

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		serviceFactory = Factory.getInstance();

		ca = new CustomerAccount("brenda", "1234 place", "me@aol.com", "16", "4", "user", "pass");

		frc.setCa(ca);

		log4jInitialization.startLog();
		log = Logger.getLogger(CustomerAccountImplTest.class);

	}

	public final void testCreditCardInformation() {

		ICustomerAccountService icas;

		try {
			icas = (ICustomerAccountService) serviceFactory.getService(ICustomerAccountService.NAME);

			assertTrue(icas.authenticateCreditCard(frc));

			log.info("testCreditCardInformation Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadingException");
			log.debug("ServiceLoadingException");
		} catch (InvalidCreditCardException icce) {
			icce.printStackTrace();
			fail("InvalidCreditCardException");
			log.debug("InvalidCreditCardException");
		}

		try {

			CustomerAccountImpl cai = (CustomerAccountImpl) serviceFactory.getService(ICustomerAccountService.NAME);

			assertTrue(cai.authenticateCreditCard(frc));

			log.info("testCreditCardInformation Passed");

		} catch (ServiceLoadingException e) {
			e.printStackTrace();
			fail("ServiceLoadException");
			log.debug("ServiceLoadingException");
		} catch (InvalidCreditCardException icce) {
			icce.printStackTrace();
			fail("InvalidCreditCardException");
			log.debug("InvalidCreditCardException");

		}
	}
}

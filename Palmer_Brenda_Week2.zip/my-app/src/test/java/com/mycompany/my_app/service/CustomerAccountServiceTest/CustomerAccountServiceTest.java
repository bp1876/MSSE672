/**
 * 
 */
package com.mycompany.my_app.service.CustomerAccountServiceTest;

import org.junit.jupiter.api.BeforeEach;
import org.apache.log4j.Logger;

import com.mycompany.my_app.domain.CustomerAccount;
import com.mycompany.my_app.driver.log4jInitialization;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class CustomerAccountServiceTest extends TestCase {

	static Logger log = null;
	private CustomerAccount customeraccount1, customeraccount2;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	protected void setUp() throws Exception {
		super.setUp();

		customeraccount1 = new CustomerAccount("brenda", "1234 place", "me@aol.com", "16", "4", "user", "pass");
		customeraccount2 = new CustomerAccount("brenda", "1234 place", "me@aol.com", "16", "4", "user", "pass");
		log4jInitialization.startLog();
		log = Logger.getLogger(CustomerAccountServiceTest.class);

	}

	/**
	 * Casting Factory output to ICustomerAccountService
	 * 
	 */
	public final void testauthenticateCreditCard() {

		assertTrue("CustomerAccount validates", customeraccount1.validate());

		log.info("testauthenticateCreditCard Passed");
	}

	public final void testEqualsAuthenticateCreditCard() {

		assertTrue("customeraccount1 equals customeraccount2", customeraccount1.equals(customeraccount2));

		log.info("testEqualsAuthenticateCreditCard Passed");
	}
}

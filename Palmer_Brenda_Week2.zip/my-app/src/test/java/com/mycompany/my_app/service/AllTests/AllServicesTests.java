/**
 * 
 */
package com.mycompany.my_app.service.AllTests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.mycompany.my_app.service.BookItineraryServiceTest.BookItineraryImplTest;
import com.mycompany.my_app.service.BookItineraryServiceTest.BookItineraryServiceTest;
import com.mycompany.my_app.service.CustomerAccountServiceTest.CustomerAccountImplTest;
import com.mycompany.my_app.service.CustomerAccountServiceTest.CustomerAccountServiceTest;
import com.mycompany.my_app.service.FactoryTest.FactoryServiceTest;
import com.mycompany.my_app.service.ListAvailableItineraryOptionsServiceTest.ListAvailableItineraryOptionsImplTest;
import com.mycompany.my_app.service.ListAvailableItineraryOptionsServiceTest.ListAvailableItineraryOptionsServiceTest;
import com.mycompany.my_app.service.LoginServiceTest.LoginImplTest;
import com.mycompany.my_app.service.LoginServiceTest.LoginServiceTest;
import com.mycompany.my_app.service.ReserveItineraryServiceTest.ReserveItineraryImplTest;
import com.mycompany.my_app.service.ReserveItineraryServiceTest.ReserveItineraryServiceTest;
import com.mycompany.my_app.service.SearchFlightInformationServiceTest.SearchFlightInformationImplTest;
import com.mycompany.my_app.service.SearchFlightInformationServiceTest.SearchFlightInformationServiceTest;


/**
 * @author Brenda Palmer
 *
 */

//The following will get all the Test classes and then execute them at once
@RunWith(Suite.class)
@SuiteClasses({ FactoryServiceTest.class, CustomerAccountServiceTest.class, LoginServiceTest.class,
		SearchFlightInformationServiceTest.class, ListAvailableItineraryOptionsServiceTest.class,
		ReserveItineraryServiceTest.class, BookItineraryServiceTest.class, CustomerAccountImplTest.class, LoginImplTest.class,
		SearchFlightInformationImplTest.class, ListAvailableItineraryOptionsImplTest.class,
		ReserveItineraryImplTest.class, BookItineraryImplTest.class})
public class AllServicesTests {

}

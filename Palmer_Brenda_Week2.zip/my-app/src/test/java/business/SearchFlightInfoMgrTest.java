/**
 * 
 */
package business;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import business.exception.ServiceLoadingException;
import com.mycompany.my_app.domain.SearchFlightInformation;
import com.mycompany.my_app.service.exception.InvalidSearchFlightException;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class SearchFlightInfoMgrTest extends TestCase {

	@SuppressWarnings("unused")
	private SearchFlightInformation sfi;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	protected void setUp() throws Exception {
		super.setUp();

		sfi = new SearchFlightInformation("031920", "5am", "DEN", "032020", "1pm", "AAA", "2", "false", "true");
	}

	@Test
	public void testCreateSearchFlightInformation() throws ServiceLoadingException, InvalidSearchFlightException {
		assertTrue(Manager.class.isAssignableFrom(SearchFlightInfoManager.class));

		System.out.println("testCreateSearchFlightInformation Passed");
	}
	
	

}
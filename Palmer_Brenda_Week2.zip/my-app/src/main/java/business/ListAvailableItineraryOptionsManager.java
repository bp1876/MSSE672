/**
 * 
 */
package business;

import business.exception.ServiceLoadingException;
import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.domain.ListAvailableItineraryOptions;
import com.mycompany.my_app.service.exception.InvalidOptionsListException;
import com.mycompany.my_app.service.factory.Factory;
import com.mycompany.my_app.service.listavailableitineraryoptionsservice.IListAvailableItineraryOptionsService;

/**
 * @author Brenda Palmer
 *
 */
public class ListAvailableItineraryOptionsManager extends Manager {

	public ListAvailableItineraryOptionsManager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static boolean avaliableOptions = false;  //if fails change to true
	
	public void createListOptions(FlightReservationComposite frc)
			throws ServiceLoadingException, InvalidOptionsListException {

		Factory factory = Factory.getInstance();

		try {

			IListAvailableItineraryOptionsService ilaios = (IListAvailableItineraryOptionsService) factory
					.getService(IListAvailableItineraryOptionsService.NAME);
			ilaios.optionsList(frc);
		} catch (ServiceLoadingException sle) {
			sle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void viewListOptions(FlightReservationComposite frc) {

	}

	public void updateListOptions(FlightReservationComposite frc) {

	}

	public void deleteListOptions(FlightReservationComposite frc) {

	}

	public boolean getListOptions(ListAvailableItineraryOptions laio) {

		return true;
	}

	public void generateStatement(FlightReservationComposite frc) {

	}

}

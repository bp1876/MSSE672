/**
 * 
 */
package business;

import business.exception.ServiceLoadingException;
import com.mycompany.my_app.service.IService;
import com.mycompany.my_app.service.factory.Factory;

/**
 * @author Brenda Palmer
 * 
 * This is the Manager SuperType
 *
 */
public class Manager {

	private Factory factory = Factory.getInstance();
	
	protected IService getService (String svcName) throws ServiceLoadingException{
		
		return factory.getService(svcName);
	}
}

/**
 * 
 */
package business;

import business.exception.ServiceLoadingException;
import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.domain.ReserveItinerary;
import com.mycompany.my_app.service.exception.InvalidReserveFlightException;
import com.mycompany.my_app.service.factory.Factory;
import com.mycompany.my_app.service.reserveitineraryservice.IReserveItineraryService;

/**
 * @author Brenda Palmer
 *
 */
public class ReserveItineraryManager extends Manager {

	public ReserveItineraryManager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static boolean reserveFlight = false;

	public void createReserveFlight(FlightReservationComposite frc)
			throws ServiceLoadingException, InvalidReserveFlightException {

		Factory factory = Factory.getInstance();

		try {

			IReserveItineraryService ri = (IReserveItineraryService) factory.getService(IReserveItineraryService.NAME);
			ri.reserveFlight(frc);
		} catch (ServiceLoadingException sle) {
			sle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void viewReserveFlight(FlightReservationComposite frc) {

	}

	public void updateReserveFlight(FlightReservationComposite frc) {

	}

	public void deleteReserveFlight(FlightReservationComposite frc) {

	}

	public boolean getReserveFlight(ReserveItinerary ri) {

		return true;
	}

	public void generateStatement(FlightReservationComposite frc) {

	}

}

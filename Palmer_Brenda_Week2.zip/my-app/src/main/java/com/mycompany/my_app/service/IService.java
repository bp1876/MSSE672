/**
 * 
 */
package com.mycompany.my_app.service;

/**
 * @author Brenda Palmer
 * 
 * Marker Interface
 *
 */
public interface IService {
	
	
}

package com.mycompany.my_app.service.reserveitineraryservice;

import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.service.IService;
import com.mycompany.my_app.service.exception.InvalidReserveFlightException;

/**
 * @author Brenda Palmer
 *
 */

//Interface for ReserveItineraryService
public interface IReserveItineraryService extends IService{
	
	public final String NAME = "IReserveItineraryService";

	public boolean reserveFlight(FlightReservationComposite frc) throws InvalidReserveFlightException;

}

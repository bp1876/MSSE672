package com.mycompany.my_app.service.customeraccountservice;


import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.service.IService;
import com.mycompany.my_app.service.exception.InvalidCreditCardException;

/**
 * @author Brenda Palmer
 *
 */
// Interface for CustomerAccountService
public interface ICustomerAccountService extends IService{
	
	public final String NAME ="ICustomerAccountService";

	public boolean authenticateCreditCard(FlightReservationComposite frc) throws InvalidCreditCardException;

}

package com.mycompany.my_app.service.bookitineraryservice;


import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.service.IService;
import com.mycompany.my_app.service.exception.InvalidBookFlightException;

/**
 * @author Brenda Palmer
 *
 */
//Interface for BookItineraryService
public interface IBookItineraryService extends IService{
	
	public final String NAME = "IBookItineraryService";

	public boolean bookFlight(FlightReservationComposite frc) throws InvalidBookFlightException;

}

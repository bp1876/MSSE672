package com.mycompany.my_app.service.searchflightinformationservice;

import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.service.IService;
import com.mycompany.my_app.service.exception.InvalidSearchFlightException;

/**
 * @author Brenda Palmer
 *
 */

//Interface for SearchFlightInformationService
public interface ISearchFlightInformationService extends IService{
	
	public final String NAME = "ISearchFlightInformationService";

	public boolean searchFlights(FlightReservationComposite frc) throws InvalidSearchFlightException;

}

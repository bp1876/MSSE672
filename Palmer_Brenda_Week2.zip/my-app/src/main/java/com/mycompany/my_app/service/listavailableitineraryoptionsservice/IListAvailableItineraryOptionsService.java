package com.mycompany.my_app.service.listavailableitineraryoptionsservice;

import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.service.IService;
import com.mycompany.my_app.service.exception.InvalidOptionsListException;

/**
 * @author Brenda Palmer
 *
 */
//Interface for ListAvailableItineraryOptionsService
public interface IListAvailableItineraryOptionsService extends IService{
	
	public final String NAME = "IListAvailableItineraryOptionsService";

	public boolean optionsList(FlightReservationComposite frc) throws InvalidOptionsListException;

}

package com.mycompany.my_app.service.loginservice;

import com.mycompany.my_app.domain.FlightReservationComposite;
import com.mycompany.my_app.service.IService;
import com.mycompany.my_app.service.exception.InvalidLoginException;

/**
 * @author Brenda Palmer
 *
 */

//Interface for LoginService
public interface ILoginService extends IService{
	
	public final String NAME = "ILoginService";

	public boolean authenticateUser(FlightReservationComposite frc) throws InvalidLoginException;

}
